## Done by
Muteeb Akram Nawaz, Doctor (u1471482)

## Run Experiments

```sh
sh run.sh
```

## To see the Output I got.

```sh
cat ExperimentResults.txt
```
